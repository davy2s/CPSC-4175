import java.util.Random;
public class Battle
{
    Troops[][] battleField;
    PlayerData playersData;
    Troops[] enemyTroops;
    public Battle( PlayerData playerData){
        playersData = playerData;
        battleField = new Troops[12][12];

        //         playersData.addTroopList(new Troops());
        //         int a =2;
        //         int b = 5;
        //         int i= 0;
        //         if (battleField[a][b] ==null){
        // 
        //             battleField[a][b] = playersData.troopList.get(i);
        //             battleField[a][b] = null;
        //         }
    }

    public void setEnemyTroops(){
        Random r =new Random();
        int enemyNumber = r.nextInt((playersData.troopList.size()+1))+1;
        enemyTroops = new Troops[enemyNumber];
        for( int i =0; i < enemyNumber; i++){
            int enemyType = r.nextInt(3);
            switch(enemyType){
                case 0 :
                enemyTroops[i] = new Troops("footman","E");
                break;
                case 1 :
                enemyTroops[i] = new Troops("knight","E");
                break;
                case 2 :
                enemyTroops[i] = new Troops("longbowman","E");
                break;
            }
            int x = r.nextInt(12);
            int y = r.nextInt(12);
            while(!(battleField[x][y] == null)){
                x = r.nextInt(12);
                y = r.nextInt(12);
            }
            battleField[x][y] = enemyTroops[i];
            enemyTroops[i].setX(x);
            enemyTroops[i].setY(y);
        }

    }

    public void setPlayerTroops(){
        Random r =new Random();
        for( int i =0; i < playersData.troopList.size(); i++){
            int x = r.nextInt(12);
            int y = r.nextInt(12);
            while(!(battleField[x][y] == null)){
                x = r.nextInt(12);
                y = r.nextInt(12);
            }
            battleField[x][y] = playersData.troopList.get(i);
            playersData.troopList.get(i).setX(x);
            playersData.troopList.get(i).setY(y);
        }
    }

    public void printBattleField(){
        System.out.println("  ");
        for( int y =0; y <battleField[0].length ; y++){
            System.out.printf("%6s",y);
        }
        System.out.println();
        for( int x =0; x <battleField.length ; x++){
            System.out.printf("%2s",x);
            for( int y =0; y <battleField[x].length ; y++){
                if (!(battleField[y][x]==null)){
                    System.out.printf("[%2s]  ",battleField[y][x].getPlayer());
                }
                else{
                    System.out.printf("[%2s]  ","");
                }

            }
            System.out.println();
        }
    }

    public String checkFinished(){
        boolean enemyCheck = false;
        boolean playerCheck = false;
        for(int i = 0; i < enemyTroops.length; i ++){
            if(enemyTroops[i].getStatus()){
                enemyCheck = true;
                continue;
            }
        }
        for(int i = 0; i < playersData.troopList.size(); i ++){
            if(playersData.troopList.get(i).getStatus()){
                playerCheck = true;
                continue;
            }
        }
        if(enemyCheck){
            return "Player won!";
        }
        else if(playerCheck){
            return "Enemy won!";
        }
        else{
            return "";
        }
    }

    public Troops selectUnit(int x, int y){
        if(battleField[x][y] != null){
            return battleField[x][y];
        }
        else{
            System.out.println("There isn't a troop there");
            return null;
        }
    }

    public void move(int x, int y, Troops selectedTroop){
        if(selectedTroop != null){
            if(!(selectedTroop.getMoved())){
                int test1 = java.lang.Math.abs(x-selectedTroop.getX());
                if(!(java.lang.Math.abs(x-selectedTroop.getX()) > selectedTroop.getMoveSpace())){
                    int test2 = java.lang.Math.abs(y-selectedTroop.getY());
                    if(!(java.lang.Math.abs(y-selectedTroop.getY()) > selectedTroop.getMoveSpace())){
                        if(battleField[x][y] == null){
                            battleField[selectedTroop.getX()][selectedTroop.getY()] = null;
                            battleField[x][y] = selectedTroop;
                            selectedTroop.setX(x);
                            selectedTroop.setY(y);
                            selectedTroop.setMoved(true);
                        }
                        else{
                            System.out.println("There is someone in that spot");
                        }
                    } 
                    else{
                        System.out.println("This move did not have a valid y");
                    }
                }
                else{
                    System.out.println("This move did not have a valid x");
                }
            }
            else{
                System.out.println("This troop has already moved");
            }
        }
        else{
            System.out.println("There is no selected troop");
        }
    }

    public void attack(int x, int y, Troops selectedTroop){
        if(!(selectedTroop.getAttacked())){
            if(!(java.lang.Math.abs(x-selectedTroop.getX()) > selectedTroop.getRange())){
                if(!(java.lang.Math.abs(y - selectedTroop.getY()) > selectedTroop.getRange())){
                    if(battleField[x][y] != null){
                        battleField[x][y].setMaxHealth(battleField[x][y].getMaxHealth() - selectedTroop.getDamage());
                        selectedTroop.setAttacked(true);
                        if(battleField[x][y].getMaxHealth() <= 0){
                            battleField[x][y] = null;
                        }
                    }
                    else{
                        System.out.println("That space is empty");
                    }
                }
                else{
                    System.out.println("This y is not in range");
                }
            }
            else{
                System.out.println("This x is not in range");
            }
        }
        else{
            System.out.println("This troop has already attacked");
        }
    }

    public void endTurn(){
        for(int i = 0; i < playersData.troopList.size(); i++){
            playersData.troopList.get(i).setAttacked(false);
            playersData.troopList.get(i).setMoved(false);
        }
    }
}
